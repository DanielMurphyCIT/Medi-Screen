package com.example.mediscreen;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class PatientInformation extends AppCompatActivity {

    TextView cancer;
    EditText bmi;
    EditText glucose;
    EditText insulin;
    EditText homa;
    EditText lepti;
    EditText andiponectin;
    EditText resistin;
    EditText mcp;
    EditText classification;
    EditText age;
    TextView heartDisease;
    EditText sex;
    EditText chest;
    EditText restingbp;
    EditText fasting;
    EditText serum;
    EditText electro;
    EditText maxHeart;
    EditText exercise;
    EditText depression;
    EditText slope;
    EditText vessels;
    EditText thal;
    EditText diagnosis;
    Button submit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_patient_information);

        cancer = (TextView) findViewById(R.id.cancer);
        bmi = (EditText) findViewById(R.id.bmi);
        glucose = (EditText) findViewById(R.id.glucose);
        insulin = (EditText) findViewById(R.id.insulin);
        homa = (EditText) findViewById(R.id.homa);
        lepti = (EditText) findViewById(R.id.lepti);
        andiponectin = (EditText) findViewById(R.id.andiponectin);
        resistin = (EditText) findViewById(R.id.resistin);
        mcp = (EditText) findViewById(R.id.mcp);
        classification = (EditText) findViewById(R.id.classification);
        age = (EditText) findViewById(R.id.age);
        heartDisease = (TextView) findViewById(R.id.heartDisease);
        sex = (EditText) findViewById(R.id.sex);
        chest = (EditText) findViewById(R.id.chest);
        restingbp = (EditText) findViewById(R.id.restingbp);
        fasting = (EditText) findViewById(R.id.fasting);
        serum = (EditText) findViewById(R.id.serum);
        electro = (EditText) findViewById(R.id.electro);
        maxHeart = (EditText) findViewById(R.id.maxHeart);
        exercise = (EditText) findViewById(R.id.exercise);
        depression = (EditText) findViewById(R.id.depression);
        slope = (EditText) findViewById(R.id.slope);
        vessels = (EditText) findViewById(R.id.vessels);
        thal = (EditText) findViewById(R.id.thal);
        diagnosis = (EditText) findViewById(R.id.diagnosis);


        Button submit = findViewById(R.id.submit);
        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendToDatabase();
            }
        });
    }

    private void sendToDatabase() {


    }

}

