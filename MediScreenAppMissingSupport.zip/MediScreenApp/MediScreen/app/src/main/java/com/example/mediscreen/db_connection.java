package com.example.mediscreen;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLEncoder;

public class db_connection {

    // Create sendText Method
    public String sendLoginText(String query, String location, String password) throws UnsupportedEncodingException {
        String res = "Default Value of res";
        // Create data variable for sent values to server
        String data = URLEncoder.encode("appQuery", "UTF-8")
                + "=" + URLEncoder.encode(query, "UTF-8");
        data += "&" + URLEncoder.encode("appPassword", "UTF-8")
                + "=" + URLEncoder.encode(password, "UTF-8");

        System.out.println("We are sending this data: " + data);
        BufferedReader reader = null;

        // Send data
        try {

            // Defined URL  where to send data
            URL url = new URL("http://176.34.142.64/Medi-Screen-Web-Portal/"+location);

            // Send POST data request
            URLConnection conn = url.openConnection();
            System.out.println("connection made");
            conn.setDoOutput(true);
            OutputStreamWriter wr = new OutputStreamWriter(conn.getOutputStream());
            wr.write(data);
            wr.flush();

            // Get the server response
            reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            StringBuilder sb = new StringBuilder();
            String line = null;

            // Read Server Response
            while ((line = reader.readLine()) != null) {
                // Append server response in string
                sb.append(line + "\n");
                System.out.println("waiting for server response");
            }


            res = sb.toString();
            System.out.println("res: "+res+"--");
        } catch (Exception ex) {
            System.out.println("error found here: " + ex);
            ex.printStackTrace();
        } finally {
            try {
                reader.close();
                System.out.println("we have clsed the reader");
            } catch (Exception ex) {
                System.out.println("error found here aswelllllll: " + ex);
                ex.printStackTrace();
            }
        }
        return res;
    }

    public String sendText(String query, String location) throws UnsupportedEncodingException {
        String res = "Default Value of res";
        // Create data variable for sent values to server
        String data = URLEncoder.encode("appQuery", "UTF-8")
                + "=" + URLEncoder.encode(query, "UTF-8");

        System.out.println("We are sending this data: " + data);
        BufferedReader reader = null;

        // Send data
        try {

            // Defined URL  where to send data
            URL url = new URL("http://176.34.142.64/Medi-Screen-Web-Portal/"+location);

            // Send POST data request
            URLConnection conn = url.openConnection();
            System.out.println("connection made");
            conn.setDoOutput(true);
            OutputStreamWriter wr = new OutputStreamWriter(conn.getOutputStream());
            wr.write(data);
            wr.flush();

            // Get the server response
            reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            StringBuilder sb = new StringBuilder();
            String line = null;

            // Read Server Response
            while ((line = reader.readLine()) != null) {
                // Append server response in string
                sb.append(line + "\n");
                System.out.println("waiting for server response");
            }


            res = sb.toString();
        } catch (Exception ex) {
            System.out.println("error found here: " + ex);
            ex.printStackTrace();
        } finally {
            try {
                reader.close();
                System.out.println("we have clsed the reader");
            } catch (Exception ex) {
                System.out.println("error found here aswelllllll: " + ex);
                ex.printStackTrace();
            }
        }
        return res;
    }
}