package com.example.mediscreen;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class medi_ai_option extends AppCompatActivity implements View.OnClickListener {

    private TextView heartDisease;
    private TextView diabetes;
    private TextView breastCancer;
    private TextView notice;
    private Button recalculateButton;
    private Button exit;
    private String[] userData;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_medi_ai_option);

        heartDisease = findViewById(R.id.heartDisease);
        diabetes = findViewById(R.id.diabetes);
        breastCancer = findViewById(R.id.breastCancer);
        notice = findViewById(R.id.notice);
        recalculateButton = findViewById(R.id.recalculate);
        exit = findViewById(R.id.exitButton);

        recalculateButton.setOnClickListener(this);
        exit.setOnClickListener(this);

        Intent intent = getIntent();
        userData = intent.getStringArrayExtra("accountDetails");

        getPredictions();
        getAccuracy();
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){
            case R.id.recalculate:
                db_connection conn = new db_connection();
                try {
                    String res = conn.sendText("update medicalHistory set beenCalculated = 0" +
                            " where patientID ='" + userData[3] + "';", "updateMedicalHistory.php");
                    if(res.equals("DONE\n")){
                        createAlert("Recalculating", " Our machine learning models " +
                                " will now recalculate your result");
                    }
                    else{
                        createAlert("Database Error", "Please try again or contact support if the issue remains");
                    }
                }
                catch (Exception e){
                    createAlert("Database Error", "Please try again or contact support if the issue remains");
                }
                break;

            case R.id.exitButton:
                Intent intent = new Intent(medi_ai_option.this, MainActivity.class);
                // do a query and check could we log in
                intent.putExtra("loggedIn", true);
                intent.putExtra("accountDetails", userData);
                startActivity(intent);
                break;
        }
    }

    private void getPredictions(){
        db_connection conn = new db_connection();
        String res = "";

        try {
            res = conn.sendText("Select * from predictions where patientID = '" + userData[3] +
                    "';", "getPredictions.php");
            String[] data = res.split(",");
            System.out.println("--"+res+"--");
            Log.d("MyApp",res);
            if(!data[0].equals("ERROR")){
                heartDisease.setText("Heart Disease Result: "+data[0]);
                diabetes.setText("Diabetes Result: "+data[1]);
                breastCancer.setText("Breast Cancer Result"+data[2]);
            }
            else{
                createAlert("Database Error", "Please try again, if the issue remains contact support");
            }
        }catch (Exception e){
            createAlert("APP Error", e.getMessage());
            e.printStackTrace();
        }

    }

    private void getAccuracy(){
        db_connection conn = new db_connection();
        String res = "";
        try {
            res = conn.sendText("Select * from models;","getAccuracy.php");
            if(!res.equals("NO MODELS\n")){
                res = res.replace("," ," : ");
                notice.setText("Here is the accuracy for our Machine learning models:\n\n"+res);
            }
            else{
                createAlert("Database Error", "Please try again, if the issue remains contact support");
            }
        }catch (Exception e){
            createAlert("APP Error", e.getMessage());
            e.printStackTrace();
        }
    }

    // Create and display an alert
    public void createAlert(String title, String message){
        // Create dialog building set title and a message
        AlertDialog.Builder builder = new AlertDialog.Builder(medi_ai_option.this);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }
}
