package com.example.mediscreen;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;

public class medicalHistory extends AppCompatActivity implements View.OnClickListener {

    ArrayList<EditText>textBoxes = new ArrayList<>();
    ArrayList<Float>inputtedValues = new ArrayList<>();
    Button submit;
    String[] userData;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_medical_history);
        setTextBoxes();
        submit = findViewById(R.id.submitButton);
        submit.setOnClickListener(this);
        Intent intent = getIntent();
        userData = intent.getStringArrayExtra("accountDetails");

    }

    @Override
    public void onClick(View v) {
        if(v.getId() == R.id.submitButton){
            System.out.println("Button pressed");
            String res = "Undefined";
            String title;
            String message;
            int wrongCount = getAndCheckInputs();
            System.out.println(wrongCount);
            if(wrongCount == 0){
                //No issues, send the data to the database
                db_connection conn = new db_connection();
                try {
                    res = conn.sendText(createQuery(), "insertFromApp.php");

                }catch (Exception e){
                    System.out.println(e);
                }
                inputtedValues.clear();
                if(res.equals("DONE\n")){
                    title = "Data Sent Successfully";
                    message = "Please go to the Medi AI Section to see your results";
                    createAlert(title, message);
                    try{
                        wait(30);
                    }catch (Exception  e){
                        System.out.println("Error waiting after sending data");
                    }
                    Intent intent = new Intent(medicalHistory.this, MainActivity.class);
                    // do a query and check could we log in
                    intent.putExtra("loggedIn", true);
                    intent.putExtra("accountDetails", userData);
                    startActivity(intent);
                }
                else{
                    title = "Sorry there was an error";
                    message = "Please try again, contact support if the issue remains";
                    createAlert(title, message);
                }




            }
            else{
                message = "Sorry there is "+wrongCount+" wrong values inputted please try again";
                AlertDialog.Builder builder = new AlertDialog.Builder(medicalHistory.this);
                builder.setTitle("An Error Occurred");
                builder.setMessage(message);
                builder.show();
                inputtedValues.clear();
            }
        }
    }

    // Function used to get all the input boxes from the activity
    private void setTextBoxes(){
        EditText age;
        EditText bmi;
        EditText glucose;
        EditText insulin;
        EditText sex;
        EditText homa;
        EditText lepti;
        EditText adip;
        EditText resistin;
        EditText mcp;
        EditText pregnancies;
        EditText glucosePlasma;
        EditText rbp;
        EditText skinFoldThickness;
        EditText diabetesPedigreeFunction;
        EditText chest_pain;
        EditText serum;
        EditText fastingbs;
        EditText restingelectro;
        EditText maxHeart;
        EditText excercise;
        EditText stDepression;
        EditText slope;
        EditText noOfMV;
        EditText thal;
        textBoxes.add(age = findViewById(R.id.age));
        textBoxes.add(bmi = findViewById(R.id.bmi));
        textBoxes.add(glucose = findViewById(R.id.glucose));
        textBoxes.add(insulin = findViewById(R.id.insulin));
        textBoxes.add(sex = findViewById(R.id.sex));
        textBoxes.add(homa = findViewById(R.id.homa));
        textBoxes.add(lepti = findViewById(R.id.lepti));
        textBoxes.add(adip = findViewById(R.id.adip));
        textBoxes.add(resistin = findViewById(R.id.resistin));
        textBoxes.add(mcp = findViewById(R.id.mcp));
        textBoxes.add(pregnancies = findViewById(R.id.pregnancies));
        textBoxes.add(glucosePlasma = findViewById(R.id.glucosePlasma));
        textBoxes.add(rbp = findViewById(R.id.rbp));
        textBoxes.add(skinFoldThickness = findViewById(R.id.skinFoldThickness));
        textBoxes.add(diabetesPedigreeFunction = findViewById(R.id.diabetesPedigreeFunction));
        textBoxes.add(chest_pain = findViewById(R.id.chest_pain));
        textBoxes.add(serum = findViewById(R.id.serum));
        textBoxes.add(fastingbs = findViewById(R.id.fastingbs));
        textBoxes.add(restingelectro = findViewById(R.id.restingelectro));
        textBoxes.add(maxHeart = findViewById(R.id.maxHeart));
        textBoxes.add(excercise = findViewById(R.id.excercise));
        textBoxes.add(stDepression = findViewById(R.id.stDepression));
        textBoxes.add(slope = findViewById(R.id.slope));
        textBoxes.add(noOfMV = findViewById(R.id.noOfMV));
        textBoxes.add(thal = findViewById(R.id.thal));
    }

    // Function used to get all the data from the input fields
    private int getAndCheckInputs(){
        int wrongValCount = 0;
        for(EditText box : textBoxes){
            try{
                float x = Float.parseFloat(box.getText().toString());
                inputtedValues.add(x);
            }
            catch (Exception e){
                wrongValCount++;
            }
        }
        return wrongValCount;
    }

    private String createQuery(){
        String values = inputtedValues.toString();
        values = values.replace("[", "");
        values = values.replace("]","");
        String query = "insert into medicalHistory(patientID, age, bmi, glucose, insulin," +
                " sex, HOMA, lepti, adiponectin, resistin, MCP, pregnancies," +
                " glucosePlasma, bloodPressure, skinFoldThickness," +
                " diabetesPedigreeFunction, chestPainType, serumCholestoal," +
                " fastingBloodSugar, electrocardiogrpahicResults, maxHeartRate," +
                " exerciseInducedAngina, stDepressionInducedByExcercise, exerciseSlope," +
                " majorVesselAmount, thal, beenCalculated)" +
                " values ("+userData[3]+","+values+", 0);";
        return query;
    }

    // Create and display an alert
    public void createAlert(String title, String message){
        // Create dialog building set title and a message
        AlertDialog.Builder builder = new AlertDialog.Builder(medicalHistory.this);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }


}
