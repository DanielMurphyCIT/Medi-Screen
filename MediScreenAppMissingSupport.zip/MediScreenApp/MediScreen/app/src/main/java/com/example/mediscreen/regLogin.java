package com.example.mediscreen;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.io.UnsupportedEncodingException;

public class regLogin extends AppCompatActivity {

    EditText mTextUsername;
    EditText mTextPassword;
    Button loginButton;
    TextView mTextViewRegister;
    String[] data;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reg_login);

        mTextUsername = (EditText) findViewById(R.id.etUsername);
        mTextPassword = (EditText) findViewById(R.id.etPassword);
        loginButton = (Button) findViewById(R.id.loginButton);
        mTextViewRegister = (TextView) findViewById(R.id.tvRegister);

        mTextViewRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent registerIntent = new Intent(regLogin.this, registerAccount.class);
                startActivity(registerIntent);
            }

        });

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                boolean success = false;
                try{
                    success = tryToLogin();
                }
                catch (Exception e){
                    e.printStackTrace();
                }
                if(success) {
                    Intent loginIntent = new Intent(regLogin.this, MainActivity.class);
                    // do a query and check could we log in
                    loginIntent.putExtra("loggedIn", true);
                    loginIntent.putExtra("accountDetails", data);
                    startActivity(loginIntent);
                }
                else{
                    AlertDialog.Builder builder = new AlertDialog.Builder(regLogin.this);
                    builder.setTitle("Please try again");
                    builder.setMessage("Sorry, there was an issue logging in, check your details...");
                    builder.show();
                }
            }
        });
    }

    private boolean tryToLogin() throws UnsupportedEncodingException {
        boolean res = false;
        String password = mTextPassword.getText().toString();
        String email = mTextUsername.getText().toString();
        db_connection conn = new db_connection();
        String serverResponse = conn.sendLoginText( "select * from patients where email = '"+email+"';", "patientLogin.php", password);
        data = serverResponse.split(",");
        if(data[0].equals("PASS OK")){
            res = true;
        }
        return res;
    }
}