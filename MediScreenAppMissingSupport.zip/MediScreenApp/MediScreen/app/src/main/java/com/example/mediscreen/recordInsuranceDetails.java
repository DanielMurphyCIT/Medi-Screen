package com.example.mediscreen;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;

public class recordInsuranceDetails extends AppCompatActivity implements View.OnClickListener, AdapterView.OnItemSelectedListener{

    private String[] userData;
    private String[] insurers;
    private Spinner insurerSpinner;
    private TextView idText;
    private TextView fNameText;
    private TextView lNameText;
    private TextView emailText;
    private TextView location;
    private Button updateButton;
    private Button exitButton;
    private String selectedID;
    private String ourInsurerID;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_record_insurance_details);
        Intent intent = getIntent();
        userData = intent.getStringArrayExtra("accountDetails");

        //Check if there are any Insurers in the database
        getInsurerData();

        //Get all our textviews
        insurerSpinner = findViewById(R.id.insurerSpinner);
        idText = findViewById(R.id.insurerIDInput);
        fNameText = findViewById(R.id.insurerFNameInput);
        lNameText = findViewById(R.id.insurerLNameInput);
        emailText = findViewById(R.id.insurerEmailInput);
        location = findViewById(R.id.insurerLocInput);
        updateButton = findViewById(R.id.updateInsurer);
        exitButton = findViewById(R.id.exitButton);

        //Add event listeners
        updateButton.setOnClickListener(this);
        exitButton.setOnClickListener(this);

        //Spinner item check listeners
        insurerSpinner.setOnItemSelectedListener(this);

        //add list items to the spinner
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, insurers);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        insurerSpinner.setAdapter(dataAdapter);

        //Check if we have a selected Insurer
        checkMyInsurer();
    }

    @Override
    public void onClick(View v) {
        String res = "";
        switch (v.getId()){

            case R.id.updateInsurer:
                db_connection conn = new db_connection();
                String query = "update patients set insurerID = '"+selectedID+"' where patientID = '"+userData[3]+"';";
                try {
                    res = conn.sendText(query, "updateDocID.php");
                    System.out.println(res);
                }
                catch (Exception e){
                    System.out.println(e);
                }
                if(res.equals("DONE\n")){
                    String title = "All Done";
                    String message = "Your Insurer has been updated";
                    createAlert(title,message);
                }
                else{
                    String title = "Error Updating";
                    String message = "Please try again, or contact support if the issue remains";
                    createAlert(title,message);
                }

                break;

            case R.id.exitButton:
                Intent intent = new Intent(recordInsuranceDetails.this, MainActivity.class);
                // do a query and check could we log in
                intent.putExtra("loggedIn", true);
                intent.putExtra("accountDetails", userData);
                startActivity(intent);
                break;
        }
    }

    // Split data returned from server, to get each entry from the database
    private void getInsurers(String data){
        data = "Pick your Insurer here\n" + data;
        insurers = new String[data.split("\n").length];
        insurers = data.split("\n");
    }

    // Create and display an alert
    public void createAlert(String title, String message){
        // Create dialog building set title and a message
        AlertDialog.Builder builder = new AlertDialog.Builder(recordInsuranceDetails.this);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }

    private void getInsurerData(){
        db_connection conn = new db_connection();
        String query = "select * from insurers;";
        String res = "";
        try {
            res = conn.sendText(query, "selectAndReturnAllInsurerData.php");
            System.out.println(res);
        }
        catch (Exception e){
            System.out.println(e);
        }
        if(res.equals("No Insurers\n")){
            String title = "No Insurers";
            String message = "There seems to be no Insurers in the database, please ask your insurer to register";
            createAlert(title, message);
        }
        else{
            getInsurers(res);
        }
    }

    private void checkMyInsurer(){
        db_connection conn = new db_connection();
        String query = "select insurerID from patients where patientID = '"+userData[3]+"';";
        String res = "";
        try {
            res = conn.sendText(query, "getMyInsurer.php");
        }
        catch (Exception e){
            System.out.println(e);
        }
        if(res.equals("No Insurer\n")){
            String title = "No Insurer selected";
            String message = "Please select your insurer below, and click update";
            createAlert(title, message);
        }
        else{
            String[] temp = res.split(",");
            String id = temp[1].replace("\n","");
            id = id.replace(" ","");
            populateFields(id);
            ourInsurerID = id;
        }
    }

    private void populateFields(String id) {
        for (String i : insurers) {
            if (!i.equals("Pick your Insurer here")) {
                String[] insurerData = i.split(",");
                if (insurerData[0].equals(id)) {
                    idText.setText(insurerData[0]);
                    fNameText.setText(insurerData[1]);
                    lNameText.setText(insurerData[2]);
                    emailText.setText(insurerData[3]);
                    String locString = insurerData[4] + " " + insurerData[5];
                    location.setText(locString);
                }
            }
        }

    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        String item = parent.getItemAtPosition(position).toString();
        if(item.equals("Pick your Insurer here")){
            populateFields(ourInsurerID);
        }
        else {
            String[] temp = item.split(",");
            String itemID = temp[0].replace(" ", "");
            populateFields(itemID);
            selectedID = itemID;
        }

    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {
        populateFields(ourInsurerID);
    }
}
