package com.example.mediscreen;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.app.AlertDialog;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;


public class callDoctor extends AppCompatActivity {

    private static final int REQUEST_CALL = 1;
    private EditText mEditTextNumber;
    private String[] userData;
    private String ourDocID = "-1";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_call_doctor);

        Intent intent = getIntent();
        userData = intent.getStringArrayExtra("accountDetails");

        mEditTextNumber = findViewById(R.id.et_number);
        ImageView imageCall = findViewById(R.id.image_call);
        checkMyDoctor();

        if(!ourDocID.equals("-1")){
            getPhoneNum();
        }

        imageCall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                makePhoneCall();
            }
        });
    }

    private void makePhoneCall() {
        String number = mEditTextNumber.getText().toString();
        if (number.trim().length() > 0) {

            if (ContextCompat.checkSelfPermission(callDoctor.this,
                    Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(callDoctor.this,
                        new String[]{Manifest.permission.CALL_PHONE}, REQUEST_CALL);
            } else {
                String dial = "tel:" + number;
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(dial));
                startActivity(intent);
            }

        } else {
            Toast.makeText(callDoctor.this, "Enter Phone Number", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (requestCode == REQUEST_CALL) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                makePhoneCall();
            } else {
                Toast.makeText(this, "Permission DENIED", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void checkMyDoctor(){
        db_connection conn = new db_connection();
        String query = "select doctorID from patients where patientID = '"+userData[3]+"';";
        System.out.println(userData[3]);
        String res = "";
        try {
            res = conn.sendText(query, "getMyDoctor.php");
        }
        catch (Exception e){
            System.out.println(e);
        }
        if(res.equals("No Doctor\n")){
            String title = "No Doctor saved";
            String message = "Please select your doctor on the record GP Details page, and click update, then try again";
            createAlert(title, message);
        }
        else{
            String[] temp = res.split(",");
            String id = temp[1].replace("\n","");
            id = id.replace(" ","");
            ourDocID = id;
        }
    }

    // Create and display an alert
    public void createAlert(String title, String message){
        // Create dialog building set title and a message
        AlertDialog.Builder builder = new AlertDialog.Builder(callDoctor.this);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }

    private void getPhoneNum(){
        db_connection conn = new db_connection();
        String query = "Select phoneNum from doctors where doctorID ='"+ourDocID+"';";
        String res = "";
        try {
            res = conn.sendText(query, "getPhoneNum.php");
            System.out.println(res);
        }
        catch (Exception e){
            System.out.println(e);
        }
        if(!res.equals("NO NUM\n")){
            res = res.replace("\n","");
            mEditTextNumber.setText(res);
        }
    }
}