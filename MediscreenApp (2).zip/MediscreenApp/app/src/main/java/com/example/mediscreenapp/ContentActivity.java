package com.example.mediscreenapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class ContentActivity extends AppCompatActivity {

    private CardView doctorCard;
    private CardView insuranceCard;
    private CardView medi_aiCard;
    private CardView supportCard;
    private CardView ratingsCard;
    private CardView scanCard;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_content);

        doctorCard = (CardView) findViewById(R.id.doctorCard);
        insuranceCard = (CardView) findViewById(R.id.insuranceCard);
        medi_aiCard = (CardView) findViewById(R.id.medi_aiCard);
        supportCard = (CardView) findViewById(R.id.supportCard);
        ratingsCard = (CardView) findViewById(R.id.ratingsCard);
        scanCard = (CardView) findViewById(R.id.scanCard);

        doctorCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent registerIntent = new Intent(ContentActivity.this, doctorActivity.class);
                startActivity(registerIntent);
            }

        });

        insuranceCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent registerIntent = new Intent(ContentActivity.this, insuranceActivity.class);
                startActivity(registerIntent);
            }

        });

        medi_aiCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent registerIntent = new Intent(ContentActivity.this, medi_AiActivity.class);
                startActivity(registerIntent);
            }

        });

        supportCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent registerIntent = new Intent(ContentActivity.this, supportActivity.class);
                startActivity(registerIntent);
            }

        });

        ratingsCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent registerIntent = new Intent(ContentActivity.this, ratingsActivity.class);
                startActivity(registerIntent);
            }

        });

        scanCard.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent registerIntent = new Intent(ContentActivity.this, scanActivity.class);
                startActivity(registerIntent);
            }

        });

    }
}
