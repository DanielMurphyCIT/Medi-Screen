package com.example.mediscreen;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class scanOption extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scan_option);
    }
}
