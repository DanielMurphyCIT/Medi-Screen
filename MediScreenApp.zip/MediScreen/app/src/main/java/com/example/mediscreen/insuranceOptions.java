package com.example.mediscreen;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class insuranceOptions extends AppCompatActivity implements View.OnClickListener{

    private CardView recordInsDetailsCard,  payCard, callInsCard;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doctor_options);

        recordInsDetailsCard = (CardView) findViewById(R.id.recordInsDetailsCard);
        payCard = (CardView) findViewById(R.id.payCard);
        callInsCard = (CardView) findViewById(R.id.callInsCard);

        recordInsDetailsCard.setOnClickListener(this);
        payCard.setOnClickListener(this);
        callInsCard.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        Intent intent;

        switch (v.getId()) {
            case R.id.recordInsDetailsCard:
                intent = new Intent(this, recordInsuranceDetails.class);
                startActivity(intent);
                break;
            case R.id.payCard:
                intent = new Intent(this, payInsurancePremium.class);
                startActivity(intent);
                break;
            case R.id.callInsCard:
                intent = new Intent(this, callInsuranceCompany.class);
                startActivity(intent);
                break;

        }
    }
}
