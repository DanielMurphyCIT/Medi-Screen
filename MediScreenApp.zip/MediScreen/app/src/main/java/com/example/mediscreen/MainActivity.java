package com.example.mediscreen;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity implements View.OnClickListener{

    private CardView regLoginCard, doctorCard, insuranceCard, medi_aiCard, ratingCard, supportCard, scanCard;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        regLoginCard = (CardView) findViewById(R.id.regLogCard);
        doctorCard = (CardView) findViewById(R.id.doctorCard);
        insuranceCard = (CardView) findViewById(R.id.insuranceCard);
        medi_aiCard = (CardView) findViewById(R.id.medi_aiCard);
        ratingCard = (CardView) findViewById(R.id.ratingsCard);
        supportCard = (CardView) findViewById(R.id.supportCard);
        scanCard = (CardView) findViewById(R.id.regLogCard);

        regLoginCard.setOnClickListener(this);
        doctorCard.setOnClickListener(this);
        insuranceCard.setOnClickListener(this);
        medi_aiCard.setOnClickListener(this);
        ratingCard.setOnClickListener(this);
        ratingCard.setOnClickListener(this);
        supportCard.setOnClickListener(this);
        scanCard.setOnClickListener(this);

    }

    @Override
    public void onClick(View v) {
        Intent intent;

        switch (v.getId()) {
            case R.id.regLogCard : intent = new Intent(this, regLogin.class); startActivity(intent);break;
            case R.id.doctorCard : intent = new Intent(this, doctorOptions.class); startActivity(intent); break;
            case R.id.insuranceCard : intent = new Intent(this, insuranceOptions.class);startActivity(intent); break;
            case R.id.medi_aiCard : intent = new Intent(this, medi_ai_option.class);startActivity(intent); break;
            case R.id.ratingsCard : intent = new Intent(this, ratingOption.class); startActivity(intent);break;
            case R.id.supportCard : intent = new Intent(this, supportOption.class);startActivity(intent); break;
            case R.id.scanCard : intent = new Intent(this, scanOption.class); startActivity(intent);break;
            default:break;

        }

    }
}
