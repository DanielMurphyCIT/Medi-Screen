package com.example.mediscreen;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class ratingOption extends AppCompatActivity implements View.OnClickListener {

    private CardView ratingsCard;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rating_option);

        ratingsCard = (CardView) findViewById(R.id.ratingsCard);

        ratingsCard.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
            Intent intent = new Intent(this, RatingsActivity.class);
            startActivity(intent);

    }
}
