package com.example.mediscreen;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class payInsurancePremium extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pay_insurance_premium);
    }
}
