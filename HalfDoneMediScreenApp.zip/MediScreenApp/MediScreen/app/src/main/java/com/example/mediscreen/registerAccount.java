package com.example.mediscreen;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class registerAccount extends AppCompatActivity implements View.OnClickListener {

    EditText fNameTextBox;
    EditText lNameTextBox;
    EditText emailTextBox;
    EditText pass1TextBox;
    EditText pass2TextBox;
    Button submit;
    String[] userData;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_account);

        fNameTextBox = findViewById(R.id.etFirstName);
        lNameTextBox = findViewById(R.id.etLastName);
        emailTextBox = findViewById(R.id.etUsername);
        pass1TextBox = findViewById(R.id.etPassword);
        pass2TextBox = findViewById(R.id.etConfirmPassword);

        submit = findViewById(R.id.submitButtonRegister);
        submit.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        String title = "";
        String message = "";
        String res = "";
        boolean done = false;
        String[] data;
        if(v.getId() == R.id.submitButtonRegister);{
            if(pass1TextBox.getText().toString().equals(pass2TextBox.getText().toString())){
                db_connection conn = new db_connection();
                String query = "select * from patients where(email = '"+
                        emailTextBox.getText().toString()+"');";
                try {
                    res = conn.sendText(query, "checkEmail.php");
                    System.out.println(res);
                    if(res.equals("EXISTS\n")){
                        title = "Account Issue";
                        message = "Sorry there is already an account with that email, please login";
                    }
                    else if (res.equals("ACCOUNT OK\n")){
                        query = "insert into patients(fName, lName, email) values ('"+
                                fNameTextBox.getText().toString()+"', '"+lNameTextBox.getText().toString()+
                                "', '"+emailTextBox.getText().toString()+"');";
                        res = conn.sendText(query, "insertFromApp.php");
                        System.out.println(res);
                        if(res.equals("DONE\n")){
                            query = "select patientID from patients where email = '"+
                                    emailTextBox.getText().toString()+"';";
                            res = conn.sendLoginText(query,"checkPatientPass.php",pass1TextBox.getText().toString());
                            data = res.split(",");
                            System.out.println(res);
                            if(data[0].equals("PASS OK")){
                                userData = new String[3];
                                userData[0] = fNameTextBox.getText().toString();
                                userData[1] = lNameTextBox.getText().toString();
                                userData[2] = data[1];
                                Intent loginIntent = new Intent(registerAccount.this, MainActivity.class);
                                done = true;
                                // do a query and check could we log in
                                loginIntent.putExtra("loggedIn", true);
                                loginIntent.putExtra("accountDetails", userData);
                                startActivity(loginIntent);
                            }
                            else{
                                title = "Database Error";
                                message = "Please try again or contact support if the issue remains";
                            }
                        }
                        else{
                            title = "Database Error";
                            message = "Please try again or contact support if the issue remains";
                        }
                    }
                }
                catch (Exception e){
                    System.out.println(e);
                    title = "App Error";
                    message = "Please try again or contact support if the issue remains";
                }

            }
            else{
                title = "Password Issue";
                message = "Sorry the passwords don't match";
            }
            if(!done) {
                createAlert(title, message);
            }
        }
    }

    // Create and display an alert
    public void createAlert(String title, String message){
        // Create dialog building set title and a message
        AlertDialog.Builder builder = new AlertDialog.Builder(registerAccount.this);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }
}
