package com.example.mediscreen;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.RatingBar;
import android.widget.TextView;

public class RatingsActivity extends AppCompatActivity {

    private RatingBar ratingBar;
    private TextView result;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ratings);

        ratingBar = findViewById(R.id.ratingBar_id);
        result = findViewById(R.id.ratingText_id);

        result.setText("Rating: " + ratingBar.getRating());

        ratingBar.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
            @Override
            public void onRatingChanged(RatingBar ratingBar, float rating, boolean fromUser) {

                result.setText("Rating : " +rating);

            }
        });
    }
}
