package com.example.mediscreen;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class medi_ai_option extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_medi_ai_option);
    }
}
