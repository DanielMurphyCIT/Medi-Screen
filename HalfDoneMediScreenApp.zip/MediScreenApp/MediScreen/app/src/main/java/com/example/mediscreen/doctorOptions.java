package com.example.mediscreen;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class doctorOptions extends AppCompatActivity implements View.OnClickListener {

    private CardView recordDetailsCard, historyCard, callDocCard;
    private String[] userData;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doctor_options);

        recordDetailsCard = (CardView) findViewById(R.id.recordDetailsCard);
        historyCard = (CardView) findViewById(R.id.historyCard);
        callDocCard = (CardView) findViewById(R.id.callDocCard);

        recordDetailsCard.setOnClickListener(this);
        historyCard.setOnClickListener(this);
        callDocCard.setOnClickListener(this);

        Intent intent = getIntent();
        userData = intent.getStringArrayExtra("accountDetails");
    }

    @Override
    public void onClick(View v) {
        Intent intent;

        switch (v.getId()) {
            case R.id.recordDetailsCard:
                intent = new Intent(this, recordGPdetails.class);
                intent.putExtra("accountDetails",userData);
                startActivity(intent);
                break;
            case R.id.historyCard:
                intent = new Intent(this, medicalHistory.class);
                intent.putExtra("accountDetails",userData);
                startActivity(intent);
                break;
            case R.id.callDocCard:
                intent = new Intent(this, callDoctor.class);
                startActivity(intent);
                break;

        }
    }
}
