package com.example.mediscreen;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;

import java.lang.reflect.Array;
import java.util.ArrayList;

public class recordGPdetails extends AppCompatActivity implements View.OnClickListener, AdapterView.OnItemSelectedListener{

    private String[] userData;
    private String[] doctors;
    private Spinner docSpinner;
    private TextView idText;
    private TextView fNameText;
    private TextView lNameText;
    private TextView emailText;
    private TextView phoneText;
    private TextView location;
    private Button updateButton;
    private Button exitButton;
    private String selectedID;
    private String ourDocID;

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_record_gpdetails);
        Intent intent = getIntent();
        userData = intent.getStringArrayExtra("accountDetails");

        //Check if there are any doctors in the database
        getDoctorData();

        //Get all our textviews
        docSpinner = findViewById(R.id.doctorSpinner);
        idText = findViewById(R.id.doctorIDInput);
        fNameText = findViewById(R.id.doctorFNameInput);
        lNameText = findViewById(R.id.doctorLNameInput);
        emailText = findViewById(R.id.doctorEmailInput);
        phoneText = findViewById(R.id.doctorPhoneInput);
        location = findViewById(R.id.doctorLocInput);
        updateButton = findViewById(R.id.updateDoc);
        exitButton = findViewById(R.id.exitButton);

        //Add event listeners
        updateButton.setOnClickListener(this);
        exitButton.setOnClickListener(this);

        //Spinner item check listeners
        docSpinner.setOnItemSelectedListener(this);

        //add list items to the spinner
        ArrayAdapter<String> dataAdapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, doctors);
        dataAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        docSpinner.setAdapter(dataAdapter);

        //Check if we have a selected doctor
        checkMyDoctor();
    }

    @Override
    public void onClick(View v) {
        String res = "";
        switch (v.getId()){

            case R.id.updateDoc:
                db_connection conn = new db_connection();
                String query = "update patients set doctorID = '"+selectedID+"' where patientID = '"+userData[3]+"';";
                try {
                    res = conn.sendText(query, "updateDocID.php");
                    System.out.println(res);
                }
                catch (Exception e){
                    System.out.println(e);
                }
                if(res.equals("DONE\n")){
                    String title = "All Done";
                    String message = "Your GP has been updated";
                    createAlert(title,message);
                }
                else{
                    String title = "Error Updating";
                    String message = "Please try again, or contact support if the issue remains";
                    createAlert(title,message);
                }

                break;

            case R.id.exitButton:
                Intent intent = new Intent(recordGPdetails.this, MainActivity.class);
                // do a query and check could we log in
                intent.putExtra("loggedIn", true);
                intent.putExtra("accountDetails", userData);
                startActivity(intent);
        }
    }

    // Split data returned from server, to get each entry from the database
    private void getDoctors(String data){
        data = "Pick your Doctor here\n" + data;
        doctors = new String[data.split("\n").length];
        doctors = data.split("\n");
    }

    // Create and display an alert
    public void createAlert(String title, String message){
        // Create dialog building set title and a message
        AlertDialog.Builder builder = new AlertDialog.Builder(recordGPdetails.this);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }

    private void getDoctorData(){
        db_connection conn = new db_connection();
        String query = "select * from doctors;";
        String res = "";
        try {
            res = conn.sendText(query, "selectAndReturnAllData.php");
        }
        catch (Exception e){
            System.out.println(e);
        }
        if(res.equals("No Doctors\n")){
            String title = "No Doctors";
            String message = "There seems to be no doctors in the database, please ask your GP to register";
            createAlert(title, message);
        }
        else{
            getDoctors(res);
        }
    }

    private void checkMyDoctor(){
        db_connection conn = new db_connection();
        String query = "select doctorID from patients where patientID = '"+userData[3]+"';";
        String res = "";
        try {
            res = conn.sendText(query, "getMyDoctor.php");
        }
        catch (Exception e){
            System.out.println(e);
        }
        if(res.equals("No Doctor\n")){
            String title = "No Doctor selected";
            String message = "Please select your doctor below, and click update";
            createAlert(title, message);
        }
        else{
            String[] temp = res.split(",");
            String id = temp[1].replace("\n","");
            id = id.replace(" ","");
            populateFields(id);
            ourDocID = id;
        }
    }

    private void populateFields(String id) {
        for (String doc : doctors) {
            if (!doc.equals("Pick your Doctor here")) {
                String[] docData = doc.split(",");
                if (docData[0].equals(id)) {
                    idText.setText(docData[0]);
                    fNameText.setText(docData[1]);
                    lNameText.setText(docData[2]);
                    emailText.setText(docData[3]);
                    phoneText.setText(docData[4]);
                    String locString = docData[5] + " " + docData[6];
                    location.setText(locString);
                }
            }
        }

    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        String item = parent.getItemAtPosition(position).toString();
        if(item.equals("Pick your Doctor here")){
            populateFields(ourDocID);
        }
        else {
            String[] temp = item.split(",");
            String itemID = temp[0].replace(" ", "");
            populateFields(itemID);
            selectedID = itemID;
        }

    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {
        populateFields(ourDocID);
    }
}
